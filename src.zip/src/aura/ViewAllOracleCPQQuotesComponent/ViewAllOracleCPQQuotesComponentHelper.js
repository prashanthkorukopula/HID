({
	createQuote : function(component, event) {
		//get the recordId
        var recId=component.get("v.recordId");
        //method getQuotes from OracleQuoteController
		var action = component.get("c.getOpportunity");
         //set the parameter
        action.setParams({
            "recId": recId
        });
        //Register the callback function
        action.setCallback(this, function(response) {
            if(response.getState()==="SUCCESS"){
				var data = response.getReturnValue();
                if(data != null){
                    var offSet = new Date(data.Close_Date_ISO__c).getTimezoneOffset();
                    var todayDate = new Date();
                    var secondsToAdd = (offSet * 60) + 86399;
                    var d = new Date(data.Close_Date_ISO__c);
                    d.setSeconds(secondsToAdd);
                    var actionSiteId = component.get('c.getActiveSiteId');
                    //set the parameter
                    actionSiteId.setParams({
                    });
                    //Register the callback function
                    actionSiteId.setCallback(this, function(result) {
                        if(result.getState() === 'SUCCESS'){
                            var siteId = result.getReturnValue();
                            if(siteId != null){
                                if((data.StageName == 'Closed Won' || data.StageName == 'Closed Lost') && d < todayDate){
                                    component.set("v.Messageshow", true);
                                    component.set("v.errorMessage",'Cannot create quote; Opportunity either Closed or Close Date has passed!');
                                }
                                else{
                                    var urlEvent = $A.get("e.force:navigateToURL");
                                    urlEvent.setParams({
                                        "url":'/apex/BigMachines__QuoteEdit?oppId='+recId+'&actId='+data.AccountId+'&siteId='+siteId                      	            
                                    });
                                    urlEvent.fire();
                                }
                            }
                            else{
                                var urlEvent = $A.get("e.force:navigateToURL");
                                urlEvent.setParams({
                                    "url":'/apex/BigMachines__QuoteCreate?oppId='+recId+'&actId='+data.AccountId                      	            
                                });
                                urlEvent.fire();
                            }
                        }else{
                            console.log('error--:',action.getError()[0].message);
                        }
                    });
                     // Action Call
        			$A.enqueueAction(actionSiteId);         
                }                
            }else{
                var errors = action.getError();
                if(errors[0] && errors[0].message){
                    component.set("v.Messageshow", true);
                    component.set('v.errorMessage', errors[0].message);
                }
            }
        });
        // Action Call
        $A.enqueueAction(action);
	},
    clickClone: function(component,event,quoteId){
        //get the recordId
        var recId=component.get("v.recordId");
        //method getQuotes from OracleQuoteController
		var action = component.get("c.getOpportunity");
         //set the parameter
        action.setParams({
            "recId": recId
        });
        //Register the callback function
        action.setCallback(this, function(response) {
            if(response.getState()==="SUCCESS"){
				var data = response.getReturnValue();                
                if(data != null){
                    var offSet = new Date(data.Close_Date_ISO__c).getTimezoneOffset();
                    var todayDate = new Date();
                    var secondsToAdd = (offSet * 60) + 86399;
                    var d = new Date(data.Close_Date_ISO__c);
                    d.setSeconds(secondsToAdd);
                    if((data.StageName == 'Closed Won' || data.StageName == 'Closed Lost') && d < todayDate){
                        component.set("v.Messageshow", true);
                        component.set("v.errorMessage",'Cannot clone quote; Opportunity either Closed or Close Date has passed!');
                    }
                    else{
                        console.log('test');
                        var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url":'/apex/BigMachines__QuoteEdit?id='+quoteId+'&oppId='+recId+'&clone=true'                      	            
                        });
                        urlEvent.fire();
                    }
                }                
            }else{
                var errors = action.getError();
                if(errors[0] && errors[0].message){
                    component.set("v.Messageshow", true);
                    component.set('v.errorMessage', errors[0].message);
                }
            }
        });
        // Action Call
        $A.enqueueAction(action);
    },
     makePrimary:function (component,event,quoteRecId,helper){
         console.log('make--');
         var actionPrimary = component.get("c.setAsPrimary");
         actionPrimary.setParams({
             "quoteId": quoteRecId
         });
        actionPrimary.setCallback(this,function(result){
            var primaryState = result.getState();
            if(primaryState === 'SUCCESS'){
                if(result.getReturnValue() != null && result.getReturnValue() == 'success'){
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId":component.get("v.recordId")
                    });
                    navEvt.fire();
                }                    
            }else{
                console.log('error:--',action.getError()[0].message);
            }
        });
        $A.enqueueAction(actionPrimary);
         helper.hideSpinner(component);
    },
    showSpinner: function (component) {
        console.log('--showing');
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
    },
     
    hideSpinner: function (component) {
        console.log('coming--');
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
    }
})