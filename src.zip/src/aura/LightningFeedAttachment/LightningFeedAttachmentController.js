({
	doInit : function(component, event, helper) {
		
        helper.fetchFeedAttachmentDetails(component);
	}
})