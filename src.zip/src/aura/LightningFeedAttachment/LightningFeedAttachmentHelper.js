({
	fetchFeedAttachmentDetails : function(component) {
        
        var recordId = component.get("v.recordId");
        var action = component.get("c.fetchFeedAttachments");
        action.setParams({"topicId" : recordId});
        action.setCallback(this, function(response){
            
            console.log('here',response);
            var state = response.getState();
            if(component.isValid() && state === "SUCCESS"){                
                
                var returnValue = response.getReturnValue();
                console.log("returnValue>>>",returnValue);
             	component.set("v.objContentAttachmentWrapper",returnValue);
                component.set("v.dataLoaded",true);
            }else{
                
                console.log("I am in error.");
            }        	
        });
        $A.enqueueAction(action);
	}
})