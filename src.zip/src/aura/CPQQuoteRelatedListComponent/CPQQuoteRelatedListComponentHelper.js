({
	createQuote : function(component, event) {
		//get the recordId
        var recId=component.get("v.recordId");
        var data = component.get('v.oppRec');
        if(data != null && data != undefined){
            var offSet = new Date(data.Close_Date_ISO__c).getTimezoneOffset();
            var todayDate = new Date();
            var secondsToAdd = (offSet * 60) + 86399;
            var d = new Date(data.Close_Date_ISO__c);
            d.setSeconds(secondsToAdd);
            var actionSiteId = component.get('c.getActiveSiteId');
            //set the parameter
            actionSiteId.setParams({
            });
            //Register the callback function
            actionSiteId.setCallback(this, function(result) {
                if(result.getState() === 'SUCCESS'){
                    var siteId = result.getReturnValue();
                    if(siteId != null){
                        if((data.StageName == 'Closed Won' || data.StageName == 'Closed Lost') && d < todayDate){
                            component.set("v.Messageshow", true);
                            component.set("v.errorMessage",'Cannot create quote; Opportunity either Closed or Close Date has passed!');
                        }
                        else{
                            var urlEvent = $A.get("e.force:navigateToURL");
                            urlEvent.setParams({
                                "url":'/apex/BigMachines__QuoteEdit?oppId='+recId+'&actId='+data.AccountId+'&siteId='+siteId                      	            
                            });
                            urlEvent.fire();
                        }
                    }
                    else{
                        var urlEvent = $A.get("e.force:navigateToURL");
                        urlEvent.setParams({
                            "url":'/apex/BigMachines__QuoteCreate?oppId='+recId+'&actId='+data.AccountId                      	            
                        });
                        urlEvent.fire();
                    }
                }else{
                    console.log('error--:',action.getError()[0].message);
                }
            });
            // Action Call
            $A.enqueueAction(actionSiteId);         
        }                
       
	},
    clickClone: function(component,event,quoteId){
        //get the recordId
        var recId=component.get("v.recordId");
       	var data = component.get('v.oppRec');       
        if(data != null){
            var offSet = new Date(data.Close_Date_ISO__c).getTimezoneOffset();
            var todayDate = new Date();
            var secondsToAdd = (offSet * 60) + 86399;
            var d = new Date(data.Close_Date_ISO__c);
            d.setSeconds(secondsToAdd);
            if((data.StageName == 'Closed Won' || data.StageName == 'Closed Lost') && d < todayDate){
                component.set("v.Messageshow", true);
                component.set("v.errorMessage",'Cannot clone quote; Opportunity either Closed or Close Date has passed!');
            }
            else{
                var urlEvent = $A.get("e.force:navigateToURL");
                urlEvent.setParams({
                    "url":'/apex/BigMachines__QuoteEdit?id='+quoteId+'&oppId='+recId+'&clone=true'                      	            
                });
                urlEvent.fire();
            }
        }                
       
    },
     makePrimary:function (component,event,quoteRecId,helper){
         var actionPrimary = component.get("c.setAsPrimary");
         actionPrimary.setParams({
             "quoteId": quoteRecId
         });
        actionPrimary.setCallback(this,function(result){
            var primaryState = result.getState();
            if(primaryState === 'SUCCESS'){
                if(result.getReturnValue() != null && result.getReturnValue() == 'success'){
                    var navEvt = $A.get("e.force:navigateToSObject");
                    navEvt.setParams({
                        "recordId":component.get("v.recordId")
                    });
                    navEvt.fire();
                }                    
            }else{
                console.log('error:--',action.getError()[0].message);
            }
        });
        $A.enqueueAction(actionPrimary);
         helper.hideSpinner(component);
    },
    showSpinner: function (component) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-hide");
        $A.util.addClass(spinner, "slds-show");
    },
     
    hideSpinner: function (component) {
        var spinner = component.find("mySpinner");
        $A.util.removeClass(spinner, "slds-show");
        $A.util.addClass(spinner, "slds-hide");
    }
})