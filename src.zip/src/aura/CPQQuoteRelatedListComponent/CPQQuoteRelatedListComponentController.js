({
	doInit: function(component, event, helper){
        // get recordid
		var recId = component.get("v.recordId");
        //method getQuotesByOpportunity from orcalequotecontroller
		var action = component.get("c.getQuotesByOpportunity");        
        var action1 = component.get('c.getOpportunity');
		//set params
		action.setParams({
			"recId": recId
		});
        
        action1.setParams({
			"recId": recId
		});
        action1.setCallback(this, function(a){
			var state = a.getState();
			if (state === "SUCCESS") {
                var result = a.getReturnValue();
				if(result != null){
					component.set("v.oppRec", result);
                    component.set("v.oppName",result.Name);
                    // callback function
                    action.setCallback(this, function(response){
                        var state = response.getState();
                        if (state === "SUCCESS") {
                            var data = response.getReturnValue();
                            if(data != null && data.length > 0 ){
                                component.set("v.quotes", data);
                                component.set("v.hasData",true);
                                component.set("v.headerValue", "Oracle Quotes and Orders("+data.length+")");
                            }else{
                                component.set("v.headerValue", "Oracle Quotes and Orders(0)");
                                component.set("v.quotes", data);
                            }
                            
                        }else{
                            console.log('--error--',action.getError()[0].message);
                        }
                    });
                    //action call
                    $A.enqueueAction(action);
				}				
            }else{
                console.log('--error--',action1.getError()[0].message);
            }
            
		});
        //action call
		$A.enqueueAction(action1);
                
	},
    editClick: function(component, event, helper){
        var recId = component.get('v.recordId');
		if(!event.target) return;
		if(event.target.parentNode === undefined) return;

		var quoteId = event.target.getAttribute("aria-recordId")||event.target.parentNode.getAttribute("aria-recordId");
		
		var urlEvent = $A.get("e.force:navigateToURL");					
        urlEvent.setParams({
            "url": "/apex/BigMachines__QuoteEdit?retURL=/apex/axiomomd__OpportunityViewPage?id="+recId+"&id="+quoteId+"&sfdc.override=1"
        });
        urlEvent.fire();		
	},
    deleteClick:function(component, event, helper){
        if(!event.target) return;
        if(event.target.parentNode === undefined) return;
        var lstQuotes = component.get('v.quotes');
        var idx = event.target.getAttribute("data-data") || event.target.parentNode.getAttribute("data-data");
        var recId = lstQuotes[idx]["Id"];
        var action = component.get("c.deleteQuote");
        action.setParams({
            "quoteId":recId
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                lstQuotes.splice(idx, 1);
                component.set('v.quotes', lstQuotes);
            }else{
                var errors = action.getError();
                if(errors[0] && errors[0].message){
                    component.set("v.Messageshow", true);
                    component.set('v.errorMessage', errors[0].message);
                }
                
            }
        });
        $A.enqueueAction(action);
    },
    navToRelatedList: function(component, event,helper) {
        console.log('updated--');
        var evt = $A.get("e.force:navigateToComponent");
        evt.setParams({
            componentDef: "c:ViewAllOracleCPQQuotesComponent",
            isredirect: true,
            componentAttributes :{
                recordId : component.get('v.recordId')
            }
        });
        evt.fire();
    },
    navigateToSObjectDetailView: function(component, event, helper) {
        var recId = event.target.getAttribute("aria-recordId");
        var navEvt = $A.get("e.force:navigateToSObject");
        navEvt.setParams({
            "recordId": recId,
            "slideDevName": "detail"
        });
        navEvt.fire();
    },
    newQuote: function(component,event,helper){
        helper.createQuote(component,event,helper);        
    },
    cloneClick: function(component,event,helper){
        if(!event.target) return;
        if(event.target.parentNode === undefined) return;
        var lstQuotes = component.get('v.quotes');
        var idx = event.target.getAttribute("data-data") || event.target.parentNode.getAttribute("data-data");
        var quoteId = lstQuotes[idx]["Id"];
        helper.clickClone(component,event,quoteId);
    },
    setPrimary: function(component,event,helper){
		var data = component.get("v.oppRec");
		var lstQuotes = component.get('v.quotes');        
        var setAsPrimary = false;
        if(!event.target) return;
        if(event.target.parentNode === undefined) return;        
        var idx = event.target.getAttribute("data-data") || event.target.parentNode.getAttribute("data-data");
        var quoteId = lstQuotes[idx]["Id"];
        if(data != null && data != undefined){
            if(data.HasOpportunityLineItem){
                component.set('v.quoteId',quoteId);
                //show modal
                component.set("v.isOpen",true);
                
            }else{
                setAsPrimary = true;
            }
        }
        if(setAsPrimary){
            helper.makePrimary(component,event,quoteId,helper);
        }
            
    },
   
    closeModal: function(component,event,helper){
        component.set("v.isOpen",false);
    },
    OK: function(component,event,helper){
        helper.showSpinner(component);
        var quoteId = component.get('v.quoteId');
        helper.makePrimary(component,event,quoteId,helper);
    },
    closeError: function(component,event,helper){
        component.set('v.Messageshow',false);
    },
    
})