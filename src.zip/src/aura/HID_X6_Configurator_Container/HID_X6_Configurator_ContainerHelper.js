({
    initializeStore : function(component, initMap, errorMessage) {
        const self = this;
        const store = component.find('store');
        
        // ordered attributes
        const attrOrderArray = ['DPI', 'Dual Sided Printing', 'Certification', 'Lamination', 'Encoding', 'Other Options'];
        const sortedAttrDefs = this.sortAttributes(attrOrderArray, initMap.attrDefs);
        const initialStore = {
            X6Configurator: {
                orderedAttributeNames: attrOrderArray,
                attributes: sortedAttrDefs,
                selectedAttributes: {
                    DPI: '600',
                },
                isExternal: initMap.isExternal,
                userEmail: initMap.userEmail,
                firstName: initMap.firstName,
                lastName: initMap.lastName,
                currentAttribute: sortedAttrDefs[0].name,
                nextAttribute: sortedAttrDefs[1].name,
                serverErrorMessage: errorMessage,
                loading: false,
            }
        };

        store.createStore('X6Configurator', this.getReducer(), initialStore, ReduxThunk.default);
    
        var mapStateToAttributes = {
            'v.showServerMessage': state => state.X6Configurator.showServerMessage,
            'v.serverMessage': state => state.X6Configurator.serverMessage,
            'v.serverMessageType': state => state.X6Configurator.serverMessageType,
            'v.selectedProduct': state => state.X6Configurator.selectedProduct,
            'v.relatedProducts': state => state.X6Configurator.relatedProducts,
        };
        store.connect(mapStateToAttributes);
    },

    getReducer : function() {
        const self = this;
        return function(state, action, helper) {
            let newState = {};
            if (state) {
                newState = JSON.parse(JSON.stringify(state));
            }

            switch (action.type) {
                case 'LOADING':
                    newState.loading = true;
                    return newState;
                    break;
                case 'ATTRIBUTE_VALUE_SELECTED':
                    for (let i=0; i < newState.attributes.length; i++) {
                        const currentAttr = newState.attributes[i];
                        // clear out options for everything that isn't the 
                        // current or next attribute, leave in
                        // anything in newSelectedValues

                        // don't reset options if the current attribute is a dropdown, because there
                        // would only be one option based on what is returned, which isn't what we want.
                        // for a multi-select, we do want to reduce the options based on a selection
                        if (currentAttr.name == action.newCurrentAttr) {
                            if (currentAttr.inputType != 'Drop Down') {
                                currentAttr.availableOptions = action.newCurrentAttrOptions;
                            }
                        } else if (currentAttr.name == action.newNextAttr) {
                            // reset options with values from action
                            currentAttr.availableOptions = action.newNextAttrOptions;
                        } else {
                            currentAttr.availableOptions = [];
                            if (action.newSelectedValues[currentAttr.name]) {
                                currentAttr.availableOptions.push(action.newSelectedValues[currentAttr.name]);
                            }
                        }
                    }
                    newState.currentAttribute = action.newCurrentAttr;
                    newState.nextAttribute = action.newNextAttr;
                    newState.selectedAttributes = action.newSelectedValues;
                    newState.loading = false;
                    return newState;
                    break;
                case 'PRODUCT_SELECTED':
                    newState.selectedProduct = action.selectedProduct;
                    // sort related objects by type
                    newState.relatedProducts = action.relatedProducts;
                    newState.relatedConsumables = action.relatedConsumables;
                    newState.selectedAttributes = action.newSelectedValues;
                    newState.productUrl = action.productUrl;
                    newState.pdfUrl = action.pdfUrl;
                    newState.loading = false;
                    return newState;
                    break;
                case 'RESET_SELECTOR':
                    newState.attributes = self.sortAttributes(newState.orderedAttributeNames, action.resetAttributes);
                    newState.selectedAttributes = { DPI: '600' };
                    newState.loading = false;
                    newState.currentAttribute = newState.attributes[0].name;
                    newState.nextAttribute = newState.attributes[1].name;
                    newState.selectedProduct = null;
                    newState.relatedConsumables = null;
                    newState.relatedProducts = null;
                    return newState;
                    break;
                case 'SERVER_ERROR':
                    newState.serverMessage = action.message;
                    newState.serverMessageType = 'error';
                    newState.showServerMessage = true;
                    newState.loading = false;
                    return newState;
                    break;
                case 'SERVER_SUCCESS':
                    newState.serverMessage = action.message;
                    newState.serverMessageType = 'success';
                    newState.showServerMessage = true;
                    newState.loading = false;
                    return newState;
                    break;
                case 'CLOSE_SERVER_MESSAGE':
                    newState.showServerMessage = false;
                    return newState;
                    break;
                default:
                    return state || {};
            }
        }
    },

    getStringifiedSelectedVals : function(selectedValues) {
        const stringifiedSelectedVals = {};
        const keys = Object.keys(selectedValues);
        for (let i = 0; i < keys.length; i++) {
            let key = keys[i];
            if (Array.isArray(selectedValues[key])) {
                stringifiedSelectedVals[key] = selectedValues[key].join(';');
            } else {
                stringifiedSelectedVals[key] = selectedValues[key];
            }
        }
        return stringifiedSelectedVals;
    },

    sortAttributes : function(orderArray, attributeArray) {
        return attributeArray.sort((a, b) => {
            const aOrder = orderArray.findIndex(i => i === a.name);
            const bOrder = orderArray.findIndex(j => j === b.name);

            return aOrder > bOrder ? 1 : -1;
        });
    }
})