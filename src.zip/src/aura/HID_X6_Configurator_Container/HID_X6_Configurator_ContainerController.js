({
    doInit : function(component, event, helper) {
        var store = component.find('store');
        // TODO: get initial list of DPI options
        // and product list

        const initializeAction = component.get('c.initializeConfigurator');
        initializeAction.setCallback(this, function(initializerResponse) {
            if (initializerResponse.getState() === 'SUCCESS') {
                helper.initializeStore(component, JSON.parse(initializerResponse.getReturnValue()));
            } else {
                var errorMessage = 'There was an error loading the configurator. Please refresh the page.';
                var errors = appResponse.getError();
                if (errors && errors[0] && errors[0].message) {
                    errorMessage = errorMessage + '\n ' + errors[0].message;
                }
                helper.initializeStore(component, null, errorMessage);
            }
        });
        $A.enqueueAction(initializeAction);
    },

    attrValueChanged : function(component, event, helper) {
        const data = event.getParam('data');
        const store = component.find('store');
        const state = store.getState().X6Configurator;

        // this is the default state if a user changes
        // the current attribute
        let newCurrentAttr = state.currentAttribute;
        let newNextAttr = state.nextAttribute;
        
        // need to advance everything forward one if the user selected
        // a value for the 'next attribute'
        if (data.name === state.nextAttribute) {
            newCurrentAttr = state.nextAttribute;
            let curIndex = state.attributes.findIndex(i => i.name === state.nextAttribute);
            newNextAttr = curIndex === state.attributes.length - 1 ? '' : state.attributes[curIndex + 1].name;
        }

        // updated the selected value map
        let updatedSelected = JSON.parse(JSON.stringify(state.selectedAttributes));
        updatedSelected[data.name] = data.value;

        // need to change arrays to semi-colon delimited list
        // for delivery to SF
        const stringifiedSelectedVals = helper.getStringifiedSelectedVals(updatedSelected);

        const attrUpdateAction = component.get('c.fetchValueOptionsForAttribute');

        attrUpdateAction.setParams({
            currentAttribute: newCurrentAttr,
            nextAttribute: newNextAttr,
            selectedValues: stringifiedSelectedVals,
            isExternal: state.isExternal,
        });

        store.dispatch({ type: 'LOADING' });

        // query to get available options for our attributes
        attrUpdateAction.setCallback(this, (response) => {
            if (response.getState() === 'SUCCESS') {
                const resp = JSON.parse(response.getReturnValue());
                if (!resp.selectedProduct) {
                    store.dispatch({
                        type: 'ATTRIBUTE_VALUE_SELECTED',
                        newCurrentAttr: newCurrentAttr,
                        newNextAttr: newNextAttr,
                        newCurrentAttrOptions: resp.currentAttrOptions,
                        newNextAttrOptions: resp.nextAttrOptions,
                        newSelectedValues: updatedSelected,
                    });
                } else {
                    store.dispatch({
                        type: 'PRODUCT_SELECTED',
                        selectedProduct: resp.selectedProduct,
                        relatedProducts: resp.relatedProducts,
                        relatedConsumables: resp.relatedConsumables,
                        newSelectedValues: updatedSelected,
                        productUrl: resp.productImageUrl,
                        pdfUrl: resp.pdfUrl,
                    });
                }
                
            } else {
                var errorMessage = 'There was an error loading the configurator. Please refresh the page.';
                var errors = response.getError();
                if (errors && errors[0] && errors[0].message) {
                    errorMessage = errorMessage + '\n ' + errors[0].message;
                }
                store.dispatch({
                    type: 'SERVER_ERROR',
                    message: errorMessage,
                });
            }
        });

        $A.enqueueAction(attrUpdateAction);
    },

    resetAttributes : function(component, event, helper) {
        const store = component.find('store');
        const initializeAction = component.get('c.initializeConfigurator');
        
        store.dispatch({ type: 'LOADING' });
        initializeAction.setCallback(this, function(initializerResponse) {
            const resp = JSON.parse(initializerResponse.getReturnValue());
            if (initializerResponse.getState() === 'SUCCESS') {
                store.dispatch({
                    type: 'RESET_SELECTOR',
                    resetAttributes: resp.attrDefs,
                });
            } else {
                var errorMessage = 'There was an error loading the configurator. Please refresh the page.';
                var errors = appResponse.getError();
                if (errors && errors[0] && errors[0].message) {
                    errorMessage = errorMessage + '\n ' + errors[0].message;
                }
                store.dispatch({ type: 'SERVER_ERROR', message: errorMessage });
            }
        });
        $A.enqueueAction(initializeAction);
    },

    clearServerMessage : function(component, event, helper) {
        const store = component.find('store');
        store.dispatch({ type: 'CLOSE_SERVER_MESSAGE' });
    }
})