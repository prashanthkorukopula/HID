({
	doInit : function(component, event, helper) {
		//get the recordId
		var recId=component.get("v.recordId");
        console.log('recId--:',recId);
        //method getQuotes from OracleQuoteController
        var action=component.get("c.getQuotes");
        //set the parameter
        action.setParams({
			"quoteId":recId
		});
        //Register the callback function
        action.setCallback(this,function(response){
            var state=response.getState();
            if(state === "SUCCESS"){
                var data = response.getReturnValue();
                console.log('data--:',data);
                if(data != null ){
                    console.log('--test1--',data);
                    //method saveQuote from OracleQuoteController
                    var actionSave=component.get("c.saveQuote");
                    //set the parameter
                    actionSave.setParams({
                        "quote":data
                    });
                    //Register the callback function
                    actionSave.setCallback(this,function(responseSave){
                        
                        if(responseSave.getState() === "SUCCESS"){
                            var strMsg = responseSave.getReturnValue();
                            if(strMsg != null && strMsg == 'success'){
                                console.log('success');
                            }
                        }else{
                            
                            var errors = actionSave.getError();
                            console.log('error:',errors[0].message);
                            if(errors[0] && errors[0].message){
                                component.set("v.displayMessage", true);
                                component.set('v.message', errors[0].message);
                               
                            }
                        }
                    });
                    // Action Call
                    $A.enqueueAction(actionSave);
                }
            }
        });
        // Action Call
        $A.enqueueAction(action);
	}
})