({
    doInit : function(component, event, helper) {
        const store = component.find('store');


        const mapStateToAttriubtes = {
            'v.selectedAttributes': state => state.X6Configurator.selectedAttributes,
            'v.selectedProduct': state => state.X6Configurator.selectedProduct,
            'v.disabled': state => state.X6Configurator.loading,
            'v.productUrl': state => state.X6Configurator.productUrl,
            'v.pdfUrl': state => state.X6Configurator.pdfUrl,
            'v.userEmail': state => state.X6Configurator.isExternal ? '' : state.X6Configurator.userEmail,
            'v.isExternal': state => state.X6Configurator.isExternal,
            'v.firstName': state => state.X6Configurator.isExternal ? '' : state.X6Configurator.firstName,
            'v.lastName': state => state.X6Configurator.isExternal ? '' : state.X6Configurator.lastName
        };

        store.connect(mapStateToAttriubtes);
    },

    downloadPdf : function(component, event, helper) {
        const state = component.find('store').getState();
        window.open(state.X6Configurator.pdfUrl);
    },

    showEmailModal : function(component, event, helper) {
        component.set('v.showEmailModal', true);
    },

    quoteButtonPressed : function(component, event, helper) {
        const store = component.find('store');
        const prodId = store.getState().X6Configurator.selectedProduct.id;

        const quoteTaskAction = component.get('c.createQuoteTask');
        quoteTaskAction.setParams({
            productId: prodId,
        });

        quoteTaskAction.setCallback(this, (resp) => {
            if (resp.getState() === 'SUCCESS') {
                store.dispatch({
                    type: 'SERVER_SUCCESS',
                    message: 'Your request was submitted successfully.',
                });
            } else {
                store.dispatch({
                    type: 'SERVER_ERROR',
                    message: 'An unexpected error occurred. Please try again or refresh the page.',
                });
            }
        });

        $A.enqueueAction(quoteTaskAction);
    },

    showQuoteModal : function(component, event, helper) {
        component.set('v.showQuoteModal', true);
        //MktoForms2.loadForm("//app-sj20.marketo.com", "797-VPR-002", 3224, function (form){MktoForms2.lightbox(form).show();});
    },

    closeEmailModal : function(component, event, helper) {
        component.set('v.showEmailModal', false);
    },

    closeQuoteModal : function(component, event, helper) {
        component.set('v.showQuoteModal', false);
    },

    sendEmail : function(component, event, helper) {
        // TODO - show modal if isExternal is true to get email address
        if (component.find('userEmail').get('v.validity').valid &&
            component.find('firstName').get('v.validity').valid &&
            component.find('lastName').get('v.validity').valid) {
            const store = component.find('store');
            const prodId = store.getState().X6Configurator.selectedProduct.id;
            const emailAction = component.get('c.sendProductEmail');
            emailAction.setParams({
                productId: prodId,
                emailAddress: component.get('v.userEmail'),
                firstName: component.get('v.firstName'),
                lastName: component.get('v.lastName'),
                isExternal: component.get('v.isExternal') });
            emailAction.setCallback(this, (resp) => {
                if (resp.getState() === 'SUCCESS') {
                    component.set('v.showEmailModal', false);
                    store.dispatch({
                        type: 'SERVER_SUCCESS',
                        message: 'The email has been sent.',
                    });
                } else {
                    component.set('v.showEmailModal', false);
                    store.dispatch({
                        type: 'SERVER_ERROR',
                        message: 'An unexpected error occurred. Please try again or try downloading the PDF directly.',
                    });
                }
            });
            $A.enqueueAction(emailAction);
        }
    }
})