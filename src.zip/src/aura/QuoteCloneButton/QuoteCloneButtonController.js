({
	doInit : function(component, event, helper) {
		var action = component.get("c.fetchQuoteRecord");
        action.setParams({
            "recId": component.get("v.recordId")
        });
        action.setCallback(this, function(response) {
            if(response.getState()==="SUCCESS"){
                
                component.set("v.quoteRecToClone", response.getReturnValue());
                var quoteRec = component.get("v.quoteRecToClone");
                var offSet = new Date(quoteRec.Opportunity_Close_Date_ISO__c).getTimezoneOffset();
                var todayDate = new Date();
                var secondsToAdd = (offSet * 60) + 86399;
                var d = new Date(quoteRec.Opportunity_Close_Date_ISO__c);
                d.setSeconds(secondsToAdd);
                if(quoteRec.Opportunity_Stage__c.indexOf("close")==-1 && d>=todayDate){
                	var urlEvent = $A.get("e.force:navigateToURL");
                    urlEvent.setParams({
                        "url":'/apex/BigMachines__QuoteEdit?id='+quoteRec.Id+'&oppId='+quoteRec.BigMachines__Opportunity__c+'&clone=true'
                      	
            
                    });
                    urlEvent.fire();
                }
                else{
                   // throw new Error('Cannot clone quote; Opportunity either Closed or Close Date has passed!');
                    component.set("v.messageToShow",'Cannot clone quote; Opportunity either Closed or Close Date has passed!');
                   // alert('Cannot clone quote; Opportunity either Closed or Close Date has passed!');
                }
                
            }
        });
        $A.enqueueAction(action);
	}
})