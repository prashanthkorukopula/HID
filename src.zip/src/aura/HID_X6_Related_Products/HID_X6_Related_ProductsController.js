({
    doInit : function(component, event, helper) {
        const store = component.find('store');

        const mapStateToAttributes = {
            'v.products': function(state) {
                return state.X6Configurator.relatedProducts;
            },
        }

        store.connect(mapStateToAttributes);
    }
})