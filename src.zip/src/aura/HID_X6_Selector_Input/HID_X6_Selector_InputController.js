({
    doInit : function(component, event, helper) {
        const store = component.find('store');

        const mapStateToAttributes = {
            'v.attributes': function(state) {
                return state.X6Configurator.attributes;
            },
            'v.selectedAttributes': function(state) {
                return state.X6Configurator.selectedAttributes;
            },
            'v.selectedValue': function(state) {
                const attr = component.get('v.attribute');
                let value = '';
                if (state.X6Configurator.selectedAttributes[attr.name]) {
                    value = state.X6Configurator.selectedAttributes[attr.name];
                } else if (attr.inputType == 'Drop Down') {
                    value = '';
                } else {
                    value = [];
                }
                return value;
            },
            'v.currentAttribute': function(state) {
                return state.X6Configurator.currentAttribute;
            },
            'v.nextAttribute': function(state) {
                return state.X6Configurator.nextAttribute;
            },
            'v.options': function(state) {
                const stringOptions = component.get('v.attribute').availableOptions;
                const objOptions = [];
                for (let i=0; i < stringOptions.length; i++) {
                    objOptions.push({ label: stringOptions[i], value: stringOptions[i] });
                }
                return objOptions;
            },
            'v.disabled': function(state) {
                // input is disabled if:
                // a) it is not the current or next attribute
                // b) there is a call to the server going on (st.loading)
                // c) there is a selected product, so no more options need to be selected (st.selectedProduct)
                const st = state.X6Configurator;
                const attrName = component.get('v.attribute').name;
                return (st.currentAttribute != attrName && st.nextAttribute != attrName) || st.loading || st.selectedProduct;
            }
        }

        store.connect(mapStateToAttributes);
    },

    dropdownSelectionMade : function(component, event, helper) {
        var evt = component.getEvent('attrValueChanged');
        evt.setParams({
            data: {
                name: component.get('v.attribute').name,
                value: component.find(event.getSource().getLocalId()).get('v.value')
            }
        });
        evt.fire();
    },

    multiselectSelectionMade : function(component, event, helper) {
        var evt = component.getEvent('attrValueChanged');
        evt.setParams({
            data: {
                name: component.get('v.attribute').name,
                value: component.find(event.getSource().getLocalId()).get('v.value')
            }
        });
        evt.fire();
    }
})