({
    helperMethod : function() {
    }
})