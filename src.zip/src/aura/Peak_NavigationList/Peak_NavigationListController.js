({
    toggleMobileUtilNav : function(component, event, helper) {
        var cEvent = component.getEvent('toggleMobileUtilNavEvent');
        cEvent.fire();
    }
})