({
    doInit : function(component, event, helper) {
        const description = component.get('v.product').description;
        let desc = !!description && description.length > 165 ? description.slice(0, 150) : description;
        component.set('v.shortenedDescription', desc);
    }
})