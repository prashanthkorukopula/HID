({
    doInit : function(component, event, helper) {
        const store = component.find('store');

        const mapStateToAttributes = {
            'v.attributes': function(state) {
                return state.X6Configurator.attributes;
            },
            'v.disabled': function(state) {
                return state.X6Configurator.loading;
            }
        }

        store.connect(mapStateToAttributes);
    },

    attrValueChanged : function(component, event, helper) {
        var evt = component.getEvent('attrValueChanged');
        evt.setParams({
            data: event.getParam('data')
        });

        evt.fire();
    },

    resetAttributes : function(component, event, helper) {
        component.getEvent('resetAttributes').setParams({ data: {} }).fire();
    }
})